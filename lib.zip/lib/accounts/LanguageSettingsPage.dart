// import 'package:flutter/material.dart';
//
// class LanguageSettingsPage extends StatelessWidget {
//   const LanguageSettingsPage({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: const Text("Ngôn ngữ")),
//       body: ListView(
//         children: const [
//           ListTile(title: Text("🇻🇳 Tiếng Việt")),
//           ListTile(title: Text("🇺🇸 English")),
//           // TODO: Tích hợp localization thực sự nếu cần
//         ],
//       ),
//     );
//   }
// }
